# Social Likes Custom Buttons

You only need to copy CSS file from `css` folder and copypaste JS/HTML from HTML file.