**ISSUES IN ANY LANGUAGE EXCEPT ENGLISH WILL BE CLOSED**

**SUPPORT QUESTIONS WILL BE CLOSED**

**PROJECT IS NOT ACTIVELY MAINTAINED**

Which means no support, no new features and no bug fixes. I will not receive a notification about this issue.

If you want something, send a pull request and mention [sapegin](https://github.com/sapegin). If you want to maintain the project, please contact me: http://sapegin.me/

Consider using the Social Likes Next instead: http://social-likes-next.js.org/

Learn how to submit your first pull request: http://makeapullrequest.com/
