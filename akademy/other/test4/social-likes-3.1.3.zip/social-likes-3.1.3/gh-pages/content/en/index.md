name: Social Likes
title: Social Likes: beautiful social like buttons with jQuery
description: Single style social like buttons with counters for jQuery: Facebook, Twitter, Google+, Pinterest and also popular <a href="/ru/">Russian social networks</a>.
descriptionHead: Single style buttons with like counters: Facebook, Twitter, Google+, Pinterest and also popular Russian social networks.
translationLink: /ru/
translationTitle: По-русски
builderSkin: Skin
builderSkinClassic: Classic
builderSkinFlat: Flat β
builderSkinBirman: Birman β
builderType: Look
builderTypeHorizontal: Horizontal
builderTypeVertical: Vertical
builderTypeSingle: Single button
builderCounters: Show counters
builderLight: Light style
builderSites: Websites
builderUrl: URL
builderUrlHelp: When buttons used on different page
builderTitle: Title
builderTitleHelp: When differs from current page’s title
builderTwitterVia: Twitter Via
builderTwitterViaHelp: Username
builderTwitterRelated: Twitter Related
builderTwitterRelatedHelp: Username:Description
builderPinterestMedia: Image URL
builderPinterestMediaHelp: Image URL for Pinterest (required)
titleFacebook: Share link on Facebook
titleTwitter: Share link on Twitter
titlePlusone: Share link on Google+
titlePinterest: Share image on Pinterest
singleTitle: Share
downloadArchive: Download the Buttons
or: or
browseCode: view source
onGitHub: on GitHub
archiveContains: Version <a href="https://github.com/sapegin/social-likes/releases/"><!--VERSION--><!--/VERSION--></a>. Archive contains all you need to use like buttons with chosen options.
archiveFooter: <a href="http://sapegin.github.com/social-likes/">Social Likes</a> — <a href="https://github.com/sapegin/social-likes/Readme.md">documentation</a>
docs: <a href="https://github.com/sapegin/social-likes/blob/master/Readme.md">Documentation</a> and advanced customization examples.<br>Report bugs <a href="https://github.com/sapegin/social-likes/issues">on GitHub</a>.
footer: © 2014 <a href="https://github.com/sapegin">Artem Sapegin</a> and contributors. Flat skin: <a href="http://genn.org/">Genn Osypenko</a>, Birman skin: <a href="http://ilyabirman.net/">Ilya Birman</a>