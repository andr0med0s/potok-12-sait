name: Social Likes
title: Social Likes — красивые кнопки «лайков» социальных сетей с использованием jQuery
description: Красивые кнопки «лайков» со счётчиками в едином стиле для социальных сетей: Facebook, Twitter, Вконтакте, Одноклассники, Мой мир, Google+ и Pinterest. Кнопки уже используют <a href="http://www.snob.ru/">Сноб</a>, <a href="http://sberbank.ru/">Сбербанк</a>, <a href="http://blogengine.ru/blogs/">блоги на Эгее</a> и&nbsp;многие другие.
translationLink: /
translationTitle: In English
builderSkin: Скин
builderSkinClassic: Классический
builderSkinFlat: Плоский β
builderSkinBirman: Бирман β
builderType: Вид
builderTypeHorizontal: Горизонтальный
builderTypeVertical: Вертикальный
builderTypeSingle: Одной кнопкой
builderCounters: Счётчики
builderLight: Лёгкий стиль
builderSites: Сайты
builderUrl: Адрес страницы
builderUrlHelp: Если отличается от адреса страницы, где размещены кнопки
builderTitle: Название
builderTitleHelp: Если отличается от заголовка страницы, где размещены кнопки
builderTwitterVia: Twitter Via
builderTwitterViaHelp: Имя в Твиттере
builderTwitterRelated: Twitter Related
builderTwitterRelatedHelp: Имя:Описание
builderPinterestMedia: URL картинки
builderPinterestMediaHelp: URL картинки для Пинтереста (обязательно)
titleFacebook: Поделиться ссылкой на Фейсбуке
titleTwitter: Поделиться ссылкой в Твиттере
titlePlusone: Поделиться ссылкой в Гугл-плюсе
titlePinterest: Поделиться картинкой на Пинтересте
singleTitle: Поделиться
downloadArchive: Скачать кнопки
or: или
browseCode: посмотреть код
onGitHub: на Гитхабе
archiveContains: Версия <a href="https://github.com/sapegin/social-likes/releases/"><!--VERSION--><!--/VERSION--></a>. В архиве есть всё необходимое для подключения кнопок с выбранными параметрами.
archiveFooter: <a href="http://sapegin.github.com/social-likes/">Social Likes</a> — <a href="https://github.com/sapegin/social-likes/Readme.md">документация</a>
docs: <a href="https://github.com/sapegin/social-likes/blob/master/Readme.md">Документация</a>, примеры настройки и расширения.<br>Об ошибках пишите <a href="https://github.com/sapegin/social-likes/issues">на Гитхаб</a>.
footer: © 2014 <a href="https://github.com/sapegin">Артём Сапегин</a> и другие. Плоский скин: <a href="http://genn.org/">Гена Осипенко</a>, скин Бирмана: <a href="http://ilyabirman.ru/">Илья Бирман</a>