# Tooltip

Simple tooltips.


## Markup

	<div class="tooltip">I’m tooltip!</div>

	<a href="#" class="has-tooltip" data-tooltip="Call us!">+7 495 212-85-06</a>


## Skin

Set `tooltip_default_skin` or `modules_default_skin` to `true` to enable default skin.
