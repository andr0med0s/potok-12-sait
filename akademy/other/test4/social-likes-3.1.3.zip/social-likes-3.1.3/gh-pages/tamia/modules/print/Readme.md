# Print

Print stylesheet.


## Configuration

### site_domain

Type: String.

Site domain (for example, `example.com`) that will be printed.


## Caveats

Use `.no-print` class to hide elements in print version and `.print` to show (hidden on screen).
