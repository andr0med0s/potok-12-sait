# Code blocks

Nice code examples with highlighting.


## Markup

	<pre class="code"><code class="language-coffescript">alert 'Hello world!'</code></pre>

	<div class="text">
		<pre><code class="language-coffescript">alert 'Hello world!'</code></pre>
	</div>


## Tools

* [highlight.js](http://softwaremaniacs.org/soft/highlight/en/).
* [docpad-plugin-highlightjs](https://github.com/docpad/docpad-plugin-highlightjs) for DocPad.
